<?php echo e($slot); ?>

<?php /**PATH /Users/nawasena/Herd/PPDB/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>