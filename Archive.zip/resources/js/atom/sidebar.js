import { atom } from "jotai";

export const minimizeSidebarAtom = atom(false)
